package net.minecraft.entity.monster;

import java.util.Collection;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAreaEffectCloud;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import plus.fserver.ElcaMobs;
import plus.fserver.entity.ai.EntityAIHurtByTargetSlim;
import plus.fserver.entity.ai.EntityAINearestAttackableTargetPlayer;
import plus.fserver.entity.ai.EntityAIWatchClosestPlayer;

import static plus.fserver.ElcaCV.SERVER_COMPILE;


public class EntityCreeper extends EntityMob {
    private static final DataParameter<Integer> STATE = EntityDataManager.<Integer>createKey(EntityCreeper.class, DataSerializers.VARINT);
    private static final DataParameter<Boolean> POWERED = EntityDataManager.<Boolean>createKey(EntityCreeper.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> IGNITED = EntityDataManager.<Boolean>createKey(EntityCreeper.class, DataSerializers.BOOLEAN);
    private int lastActiveTime;
    private int timeSinceIgnited;
    private int fuseTime = 30;
    private int explosionRadius = 3;
    private int droppedSkulls;

    public EntityCreeper(World worldIn) {
        super(worldIn);
        this.setSize(0.6F, 1.7F);
    }


    @Override
    protected void initEntityAI() {
        EntityAITasks tasks = this.tasks;
        tasks.addTask(1, new EntityAISwimming(this));
        tasks.addTask(2, new EntityAICreeperSwell(this));
        tasks.addTask(3, new EntityAIAvoidEntity(this, EntityOcelot.class, 6.0F, 1.0D, 1.2D));
        tasks.addTask(4, new EntityAIAttackMelee(this, 1.0D, false));
        tasks.addTask(5, new EntityAIWanderAvoidWater(this, 0.8D));
        tasks.addTask(6, new EntityAIWatchClosestPlayer(this, 8.0F));
        tasks.addTask(6, new EntityAILookIdle(this));

        this.targetTasks.addTask(1, new EntityAINearestAttackableTargetPlayer(this, true));
        this.targetTasks.addTask(2, EntityAIHurtByTargetSlim.create(this, false));
    }


    @Override
    public boolean allowSprint(){
        return false;
    }


    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.25D);
    }


    @Override
    public int getMaxFallHeight() {
        return this.getAttackTarget() == null ? 3 : 3 + (int)(this.getHealth() - 1.0F);
    }


    @Override
    public void fall(float distance, float damageMultiplier) {
        super.fall(distance, damageMultiplier);
        this.timeSinceIgnited = (int)((float)this.timeSinceIgnited + distance * 1.5F);

        if (this.timeSinceIgnited > this.fuseTime - 5)
            this.timeSinceIgnited = this.fuseTime - 5;
    }


    @Override
    protected void entityInit() {
        EntityDataManager manager = getDataManager();
        manager.registerU(STATE, -1);
        manager.registerU(POWERED, Boolean.FALSE);
        manager.registerU(IGNITED, Boolean.FALSE);
        super.entityInit();
    }


    public static void registerFixesCreeper(DataFixer fixer) {
        EntityLiving.registerFixesMob(fixer, EntityCreeper.class);
    }


    @Override
    public void writeEntityToNBT(NBTTagCompound nbt) {
        super.writeEntityToNBT(nbt);

        if (this.dataManager.get(POWERED)) {
            nbt.setBoolean("powered", true);
        }
        nbt.setShortU("Fuse", (short)this.fuseTime);
        nbt.setByteU("ExplosionRadius", (byte)this.explosionRadius);
        if(this.hasIgnited())
            nbt.setBoolean("ignited", true);
    }


    @Override
    public void readEntityFromNBT(NBTTagCompound compound) {
        super.readEntityFromNBT(compound);
        this.dataManager.set(POWERED, compound.getBoolean("powered"));

        if (compound.hasKey("Fuse", 99))
            this.fuseTime = compound.getShort("Fuse");

        if (compound.hasKey("ExplosionRadius", 99))
            this.explosionRadius = compound.getByte("ExplosionRadius");

        if (compound.getBoolean("ignited"))
            this.ignite();
    }


    @Override
    public void onUpdate() {
        if (this.isEntityAlive()) {
            this.lastActiveTime = this.timeSinceIgnited;

            if (this.hasIgnited())
                this.setCreeperState(1);

            int i = this.getCreeperState();

            if (i > 0 && this.timeSinceIgnited == 0)
                this.playSound(SoundEvents.ENTITY_CREEPER_PRIMED, 1.0F, 0.5F);

            this.timeSinceIgnited += i;

            if (this.timeSinceIgnited < 0)
                this.timeSinceIgnited = 0;

            if (this.timeSinceIgnited >= this.fuseTime) {
                this.timeSinceIgnited = this.fuseTime;
                this.explode();
            }
        }
        super.onUpdate();
    }


    @Override
    protected SoundEvent getHurtSound(DamageSource damageSourceIn) {
        return SoundEvents.ENTITY_CREEPER_HURT;
    }


    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_CREEPER_DEATH;
    }


    @Override
    public void onDeath(DamageSource cause) {
        super.onDeath(cause);

        if (this.world.getGameRules().doMobLoot.getBoolean()) {
            if (cause.getTrueSource() instanceof EntitySkeleton) {
                int i = Item.getIdFromItem(Items.RECORD_13);
                int j = Item.getIdFromItem(Items.RECORD_WAIT);
                int k = i + this.rand.nextInt(j - i + 1);
                this.dropItem(Item.getItemById(k), 1);
            }
            else if (cause.getTrueSource() instanceof EntityCreeper && cause.getTrueSource() != this && ((EntityCreeper)cause.getTrueSource()).getPowered() && ((EntityCreeper)cause.getTrueSource()).ableToCauseSkullDrop()) {
                ((EntityCreeper)cause.getTrueSource()).incrementDroppedSkulls();
                this.entityDropItem(new ItemStack(Items.SKULL, 1, 4), 0.0F);
            }
        }
    }


    public boolean attackEntityAsMob(Entity entityIn) {
        return true;
    }


    public boolean getPowered() {
        return this.dataManager.get(POWERED);
    }


    @SideOnly(Side.CLIENT)
    public float getCreeperFlashIntensity(float num) {
        return ((float)this.lastActiveTime + (float)(this.timeSinceIgnited - this.lastActiveTime) * num) / (float)(this.fuseTime - 2);
    }


    @Nullable
    protected ResourceLocation getLootTable() {
        return LootTableList.ENTITIES_CREEPER;
    }


    public int getCreeperState() {
        return this.dataManager.get(STATE);
    }


    public void setCreeperState(int state) {
        this.dataManager.set(STATE, state);
    }


    @Override
    public void onStruckByLightning(EntityLightningBolt lightningBolt) {
        super.onStruckByLightning(lightningBolt);
        this.dataManager.set(POWERED, Boolean.TRUE);
    }


    @Override
    protected boolean processInteract(EntityPlayer player, EnumHand hand) {
        ItemStack itemstack = player.getHeldItem(hand);

        if (itemstack.getItem() == Items.FLINT_AND_STEEL) {
            this.world.playSound(player, this.posX, this.posY, this.posZ, SoundEvents.ITEM_FLINTANDSTEEL_USE, this.getSoundCategory(), 1.0F, this.rand.nextFloat() * 0.4F + 0.8F);
            player.swingArm(hand);

            if (!this.world.isRemote || SERVER_COMPILE) {
                this.ignite();
                itemstack.damageItem(1, player);
                return true;
            }
        }
        return super.processInteract(player, hand);
    }


    private void explode() {
        if (!this.world.isRemote || SERVER_COMPILE) {
            float f = this.getPowered() ? 2.0F : 1.0F;
            this.dead = true;
            this.world.createExplosion(this, this.posX, this.posY, this.posZ,
                    (float)this.explosionRadius * f, world.getMobGrifering(this));
            this.setDead();
            this.spawnLingeringCloud();
        }
    }


    private void spawnLingeringCloud() {
        Collection<PotionEffect> collection = this.getActivePotionEffects();

        if (!collection.isEmpty()) {
            EntityAreaEffectCloud cloud = new EntityAreaEffectCloud(this.world, this.posX, this.posY, this.posZ);
            cloud.setRadius(2.5F);
            cloud.setRadiusOnUse(-0.5F);
            cloud.setWaitTime(10);
            cloud.setDuration(cloud.getDuration() / 2);
            cloud.setRadiusPerTick(-cloud.getRadius() / (float)cloud.getDuration());

            for (PotionEffect potioneffect : collection) {
                cloud.addEffect(new PotionEffect(potioneffect));
            }

            this.world.spawnEntity(cloud);
        }
    }


    public boolean hasIgnited() {
        return this.dataManager.get(IGNITED);
    }


    public void ignite() {
        this.dataManager.set(IGNITED, Boolean.TRUE);
    }


    public boolean ableToCauseSkullDrop() {
        return this.droppedSkulls < 1 && this.world.getGameRules().doMobLoot.getBoolean();
    }


    public void incrementDroppedSkulls() {
        ++this.droppedSkulls;
    }


    @Override
    public int lodLvl() {
        return ElcaMobs.CREEPER.lodLvl(elcaMinRange);
    }
}