package net.minecraft.entity.ai.attributes;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import java.util.Collection;
import javax.annotation.Nullable;
import net.minecraft.util.LowerStringMap;
import plus.tson.utl.Te4HashMap;


public abstract class AbstractAttributeMap extends Te4HashMap<IAttribute, IAttributeInstance>{
    protected final LowerStringMap<IAttributeInstance> attributesByName = new LowerStringMap<>();
    protected final Multimap<IAttribute, IAttribute> descendantsByParent = HashMultimap.create();

    public AbstractAttributeMap(){
        super(8);
    }


    public IAttributeInstance getAttributeInstance(IAttribute attribute) {
        return super.get(attribute);
    }


    @Nullable
    public IAttributeInstance getAttributeInstanceByName(String attributeName) {
        return this.attributesByName.get(attributeName);
    }


    public IAttributeInstance registerAttribute(IAttribute attribute) {
        if (this.attributesByName.containsKey(attribute.getName())) {
            throw new IllegalArgumentException("Attribute is already registered!");
        } else {
            IAttributeInstance instance = this.createInstance(attribute);
            this.attributesByName.put(attribute.getName(), instance);
            super.put(attribute, instance);

            for (IAttribute iattribute = attribute.getParent(); iattribute != null; iattribute = iattribute.getParent()) {
                this.descendantsByParent.put(iattribute, attribute);
            }

            return instance;
        }
    }


    public IAttributeInstance registerAttributeUnsafe(IAttribute attribute) {
        IAttributeInstance instance = this.createInstance(attribute);
        this.attributesByName.put(attribute.getName(), instance);
        super.put(attribute, instance);

        for (IAttribute iattribute = attribute.getParent(); iattribute != null; iattribute = iattribute.getParent()) {
            this.descendantsByParent.put(iattribute, attribute);
        }

        return instance;
    }


    protected abstract IAttributeInstance createInstance(IAttribute attribute);


    public Collection<IAttributeInstance> getAllAttributes() {
        return this.attributesByName.values();
    }


    public void onAttributeModified(IAttributeInstance instance) {}


    public void removeAttributeModifiers(Multimap<String, AttributeModifier> modifiers) {
        for (Entry<String, AttributeModifier> entry : modifiers.entries()) {
            IAttributeInstance iattributeinstance = this.getAttributeInstanceByName(entry.getKey());

            if (iattributeinstance != null) {
                iattributeinstance.removeModifier(entry.getValue());
            }
        }
    }


    public void applyAttributeModifiers(Multimap<String, AttributeModifier> modifiers) {
        for (Entry<String, AttributeModifier> entry : modifiers.entries()) {
            IAttributeInstance iattributeinstance = this.getAttributeInstanceByName(entry.getKey());

            if (iattributeinstance != null) {
                iattributeinstance.removeModifier(entry.getValue());
                iattributeinstance.applyModifier(entry.getValue());
            }
        }
    }
}