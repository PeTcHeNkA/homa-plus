package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import plus.fserver.block.BlockFx;


public class BlockMelon extends BlockFx {
    protected BlockMelon() {
        super(Material.GOURD, MapColor.LIME);
        this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
    }


    @Override
    public Item getItemDropped(IBlockState state, Random rand, int fortune) {
        return Items.MELON;
    }


    @Override
    public int quantityDropped(Random random) {
        return 3 + random.nextInt(5);
    }


    @Override
    public int quantityDroppedWithBonus(int fortune, Random random) {
        return Math.min(9, this.quantityDropped(random) + random.nextInt(1 + fortune));
    }
}