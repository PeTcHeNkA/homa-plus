package net.minecraft.block.properties;

import com.google.common.base.Optional;
import com.google.common.collect.ImmutableSet;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import java.util.Collection;
import java.util.Set;


public class PropertyInteger extends PropertyHelper<Integer> {
    private final ImmutableSet<Integer> allowedValues;

    protected PropertyInteger(String name, int min, int max) {
        super(name, Integer.class, min, max);
        if (min < 0) {
            throw new IllegalArgumentException("Min value of " + name + " must be 0 or greater");
        } else if (max <= min) {
            throw new IllegalArgumentException("Max value of " + name + " must be greater than min (" + min + ")");
        } else {
            Set<Integer> set = new IntOpenHashSet();
            for (int i = min; i <= max; ++i) {
                set.add(i);
            }
            this.allowedValues = ImmutableSet.copyOf(set);
        }
    }


    @Override
    protected int onCalchash(int src, Object... init) {
        return 31 * ((31 * src) + init[0].hashCode()) + init[1].hashCode();
    }


    @Override
    public Collection<Integer> getAllowedValues() {
        return this.allowedValues;
    }


    @Override
    public boolean equals(Object p_equals_1_) {
        if (this == p_equals_1_) {
            return true;
        } else if (p_equals_1_ instanceof PropertyInteger && super.equals(p_equals_1_)) {
            PropertyInteger propertyinteger = (PropertyInteger)p_equals_1_;
            return this.allowedValues.equals(propertyinteger.allowedValues);
        } else {
            return false;
        }
    }


    public static PropertyInteger create(String name, int min, int max) {
        return new PropertyInteger(name, min, max);
    }


    @Override
    public Optional<Integer> parseValue(String value) {
        try {
            Integer integer = Integer.valueOf(value);
            return this.allowedValues.contains(integer) ? Optional.of(integer) : Optional.absent();
        } catch (NumberFormatException var3) {
            return Optional.absent();
        }
    }


    @Override
    public String getName(Integer value) {
        return value.toString();
    }
}