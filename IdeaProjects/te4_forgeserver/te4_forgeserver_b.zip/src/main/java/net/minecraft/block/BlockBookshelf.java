package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import plus.fserver.block.BlockFx;


public class BlockBookshelf extends BlockFx {
    public BlockBookshelf() {
        super(Material.WOOD);
        this.setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
    }


    @Override
    public int quantityDropped(Random random) {
        return 3;
    }


    @Override
    public Item getItemDropped(IBlockState state, Random rand, int fortune) {
        return Items.BOOK;
    }
}