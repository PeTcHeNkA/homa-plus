package net.minecraft.tileentity;

import net.minecraft.block.BlockBed;
import net.minecraft.init.Items;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;


public class TileEntityBed extends TileEntity {
    private EnumDyeColor color;

    public TileEntityBed() {
        this.color = EnumDyeColor.RED;
    }


    public void setItemValues(ItemStack stack) {
        this.setColor(EnumDyeColor.byMetadata(stack.getMetadata()));
    }


    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        super.readFromNBT(nbt);
        if (nbt.hasKey("color")) {
            this.color = EnumDyeColor.byMetadata(nbt.getInteger("color"));
        }
    }


    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
        super.writeToNBT(nbt);
        nbt.setIntegerU("color", this.color.getMetadata());
        return nbt;
    }


    @Override
    public NBTTagCompound getUpdateTag() {
        return this.writeToNBT(new NBTTagCompound());
    }


    @Override
    public SPacketUpdateTileEntity getUpdatePacket() {
        return new SPacketUpdateTileEntity(this.pos, 11, this.getUpdateTag());
    }


    public EnumDyeColor getColor() {
        return this.color;
    }


    public void setColor(EnumDyeColor color) {
        this.color = color;
        this.markDirty();
    }


    @SideOnly(Side.CLIENT)
    public boolean isHeadPiece() {
        return BlockBed.isHeadPiece(this.getBlockMetadata());
    }


    public ItemStack getItemStack() {
        return new ItemStack(Items.BED, 1, this.color.getMetadata());
    }
}